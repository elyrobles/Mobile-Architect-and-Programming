// This java file uses an adapter to show all items in the inventory

package com.example.elizabethroblessprojectforcs_360;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import java.util.List;

public class InventoryAdapter extends BaseAdapter {

    private List<InventoryItem> inventoryItems; // This represents the inventory items
    private Context context;
    private SQLiteDatabase db; // Implementing SQLite database to manage the inventory

    public InventoryAdapter(Context context, SQLiteDatabase db, List<InventoryItem> inventoryItems) {
        this.context = context;
        this.db = db;
        this.inventoryItems = inventoryItems;
    }

    // Returns the count of the inventory size
    @Override
    public int getCount() {
        return inventoryItems.size();
    }

    // Returns the item at the position of the inventory
    @Override
    public Object getItem(int position) {
        return inventoryItems.get(position);
    }

    // Returns the inventory ID's position
    @Override
    public long getItemId(int position) {
        return inventoryItems.get(position).id;
    }

    // This sets up the view and the decrease, increase, and deletion operations
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(R.layout.listview_item, parent, false);
        }

        TextView itemName = convertView.findViewById(R.id.itemDescription);
        TextView itemAmount = convertView.findViewById(R.id.itemAmount);
        ImageView decreaseAmount = convertView.findViewById(R.id.decreaseAmount);
        ImageView increaseAmount = convertView.findViewById(R.id.increaseAmount);
        ImageView trashItem = convertView.findViewById(R.id.trashItem);

        InventoryItem inventoryItem = inventoryItems.get(position);

        itemName.setText(inventoryItem.title);
        itemAmount.setText(String.valueOf(inventoryItem.quantity));

        // Decrease amount click listener
        decreaseAmount.setOnClickListener(view -> {
            if (inventoryItem.quantity > 0) {
                inventoryItem.quantity -= 1;
                updateQuantity(inventoryItem);
                itemAmount.setText(String.valueOf(inventoryItem.quantity));
                if (inventoryItem.quantity == 0) {
                    Intent intent = new Intent("com.example.INVENTORY_ZERO");
                    intent.putExtra("itemTitle", inventoryItem.title);
                    LocalBroadcastManager.getInstance(context).sendBroadcast(intent); // This triggers the BroadcastReceiver in the InventoryScreen.java file
                }
            }
            else {
                Toast.makeText(context, "Quantity is already 0", Toast.LENGTH_SHORT).show();
            }
        });


        // Increase amount click listener
        increaseAmount.setOnClickListener(view -> {
            inventoryItem.quantity += 1;
            updateQuantity(inventoryItem);
            itemAmount.setText(String.valueOf(inventoryItem.quantity));
        });

        // Delete item click listener
        trashItem.setOnClickListener(view -> {
            deleteItem(inventoryItem);
            inventoryItems.remove(position);
            notifyDataSetChanged();
        });

        return convertView;
    }

    // This method updates the quantity in the inventory
    private void updateQuantity(InventoryItem item) {
        ContentValues values = new ContentValues();
        values.put("quantity", item.quantity);
        db.update("inventory", values, "_id = ?", new String[] { String.valueOf(item.id) });
    }

    // This method deletes an item in the inventory
    private void deleteItem(InventoryItem item) {
        db.delete("inventory", "_id = ?", new String[] { String.valueOf(item.id) });
    }
}

