// This Java file simply represents an item inside the inventory with an item ID, an item title, and its quantity

package com.example.elizabethroblessprojectforcs_360;

public class InventoryItem {
    public long id;
    public String title;
    public int quantity;

    public InventoryItem(long id, String title, int quantity) {
        this.id = id;
        this.title = title;
        this.quantity = quantity;
    }
}
