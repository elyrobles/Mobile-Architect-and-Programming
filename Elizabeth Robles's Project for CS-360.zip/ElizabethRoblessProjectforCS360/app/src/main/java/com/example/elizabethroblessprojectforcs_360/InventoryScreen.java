// This Java file represents the functionality of the inventory_screen layout file

package com.example.elizabethroblessprojectforcs_360;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import android.Manifest;
import android.content.Intent;
import android.telephony.SmsManager;
import android.util.Log;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;


/* This InventoryScreen class includes the database for the inventory, requests the permission for SMS messages, creates a list for the inventory
   items, and the adapter for displaying the inventory items*/

public class InventoryScreen extends AppCompatActivity {
    private SQLiteDatabase db;
    private final int REQUEST_SMS_PERMISSION = 123;

    private List<InventoryItem> inventoryItems = new ArrayList<>();
    private InventoryAdapter inventoryAdapter;
    private BroadcastReceiver receiver; // broadcast receiver

    // onCreate method starts the activity and sets the layout
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inventory_scren); // UI layout

        // Managing database with a helper and getting writable access to the database as well
        InventoryDbHelper dbHelper = new InventoryDbHelper(this);
        db = dbHelper.getWritableDatabase();

        ImageView addButton = findViewById(R.id.floatingActionButton);
        addButton.setOnClickListener(v -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("New item");

            // Set up the input
            final EditText input = new EditText(this);
            builder.setView(input);

            // Set up the buttons
            builder.setPositiveButton("OK", (dialog, which) -> {
                ContentValues values = new ContentValues();
                values.put("title", input.getText().toString());
                values.put("quantity", 0);

                long newRowId = db.insert("inventory", null, values);

                // Load the updated inventory
                loadInventory();
            });

            builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

            builder.show();
        });

        // The inventory is shown because of the list view
        ListView listView = findViewById(R.id.inventory_list);
        inventoryAdapter = new InventoryAdapter(this, db, inventoryItems);
        listView.setAdapter(inventoryAdapter);

        // Setting up the notification action button
        ImageView notificationActionButton = findViewById(R.id.notificationActionButton);
        notificationActionButton.setOnClickListener(v -> {
            // Start the NotificationPermission activity here when the user hits the button
            Intent intent = new Intent(InventoryScreen.this, NotificationPermission.class);
            startActivity(intent);
        });

        loadInventory();

        // Receive the broadcast and send and SMS alert of low inventory
        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String itemTitle = intent.getStringExtra("itemTitle");
                sendSmsAlert(itemTitle);
            }
        };
    }

    // onResume and onPause below registers and unregisters the receiver when the activity is active or inactive
    @Override
    protected void onResume() {
        super.onResume();
        LocalBroadcastManager.getInstance(this).registerReceiver(receiver, new IntentFilter("com.example.INVENTORY_ZERO"));
    }
    @Override
    protected void onPause() {
        super.onPause();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(receiver);
    }

    // The inventory's database is loaded
    private void loadInventory() {
        inventoryItems.clear();  // Clear the list before loading new items

        // Information from database
        String[] projection = {
                "_id",
                "title",
                "quantity"
        };

        Cursor cursor = db.query(
                "inventory",
                projection,
                null,
                null,
                null,
                null,
                null
        );

        // These get the column index for _id, title, and quantity
        int idIndex = cursor.getColumnIndex("_id");
        int titleIndex = cursor.getColumnIndex("title");
        int quantityIndex = cursor.getColumnIndex("quantity");

        // If the column does not exist send a message, otherwise move to the next cursor and add to inventory
        if (idIndex == -1 || titleIndex == -1 || quantityIndex == -1) {
            Log.e("InventoryScreen", "One of the columns doesn't exist in the table.");
        }
        else {
            while (cursor.moveToNext()) {
                long id = cursor.getLong(idIndex);
                String title = cursor.getString(titleIndex);
                int quantity = cursor.getInt(quantityIndex);

                // add the items to the inventory and if the quantity is 0, an SMS alert will be sent
                inventoryItems.add(new InventoryItem(id, title, quantity));
                if (quantity == 0) {
                    sendSmsAlert(title);
                }
            }
        }

        cursor.close();

        // Notify the adapter that the dataset has changed
        inventoryAdapter.notifyDataSetChanged();
    }



    // This method which is called above is used when an inventory item reaches 0, an SMS alert is sent to the user
    private void sendSmsAlert(String itemTitle) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, REQUEST_SMS_PERMISSION);
        }
        else {
            String phoneNumber = "7144961953";  // my phone #
            String message = "Inventory alert: The item '" + itemTitle + "' has reached zero quantity.";
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
        }
    }

    // This method is called to grant permission or deny permission, then sends a message confirming the change
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == REQUEST_SMS_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
                loadInventory(); // Calls loadInventory() to double check and send an alert if necessary
            }
            else {
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    // Class helps to manage the database
    class InventoryDbHelper extends SQLiteOpenHelper {
        private static final String DATABASE_NAME = "inventory.db";
        private static final int DATABASE_VERSION = 1;

        public InventoryDbHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        // Method creates the SQLite database
        @Override
        public void onCreate(SQLiteDatabase db) {
            String SQL_CREATE_ENTRIES =
                    "CREATE TABLE inventory (" +
                            "_id INTEGER PRIMARY KEY," +
                            "title TEXT," +
                            "quantity INTEGER)";

            db.execSQL(SQL_CREATE_ENTRIES);
        }

        // method upgrades the database
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS inventory");
            onCreate(db);
        }
    }

}