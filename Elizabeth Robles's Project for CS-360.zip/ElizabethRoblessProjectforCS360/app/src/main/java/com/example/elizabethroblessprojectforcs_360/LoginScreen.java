// This Java file represents the functionality of the login_screen layout file

package com.example.elizabethroblessprojectforcs_360;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginScreen extends AppCompatActivity {
    SQLiteDatabase db; // Database to store usernames and passwords

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_screen); // Displays the layout for the login screen

        // Creates or opens the database and creates a table for users if it does exist
        db = openOrCreateDatabase("UsersDB", MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS users(username VARCHAR,password VARCHAR);");

        // gets all the necessary fields from the layout file
        EditText userNameEditText = findViewById(R.id.editTextText);
        EditText passwordEditText = findViewById(R.id.editTextTextPassword);
        Button signInButton = findViewById(R.id.button);
        TextView createAccountTextView = findViewById(R.id.createAccountButton);

        //Listener for the sign in button
        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get the username and password
                String userName = userNameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                /* In the code below, the username and password is checked, if it exists it will return a toast message
                   saying "Sign-in Successful" or "Invalid username or password" */
                Cursor c = db.rawQuery("SELECT * FROM users WHERE username='" + userName + "' AND password='" + password + "'", null);
                if(c.getCount() > 0) {
                    Toast.makeText(LoginScreen.this, "Sign-in Successful", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(LoginScreen.this, InventoryScreen.class);
                    startActivity(intent);
                }
                else {
                    Toast.makeText(LoginScreen.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Created a listener for the Create account text view
        createAccountTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            // gets users username and password and sends message that their account was created successfully
            public void onClick(View view) {
                String userName = userNameEditText.getText().toString();
                String password = passwordEditText.getText().toString();
                db.execSQL("INSERT INTO users VALUES('" + userName + "','" + password + "');");
                Toast.makeText(LoginScreen.this, "Account created successfully", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
