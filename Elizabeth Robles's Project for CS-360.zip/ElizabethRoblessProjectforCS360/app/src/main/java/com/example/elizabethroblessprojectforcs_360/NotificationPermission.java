// This Java file represents the functionality of the notification_permission layout file

package com.example.elizabethroblessprojectforcs_360;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class NotificationPermission extends AppCompatActivity {

    private Button allowButton;
    private Button noThanksButton;
    private ImageView backArrow;
    private final int REQUEST_SMS_PERMISSION = 123;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notification_permission); //Sets up the UI with the notification_permission layout file

        allowButton = findViewById(R.id.button_permission);
        noThanksButton = findViewById(R.id.button_proceed);
        backArrow = findViewById(R.id.backArrow);

        // Listener for when the user hits the allow button
        allowButton.setOnClickListener(v -> {
            // Checks to see if my inventory app has permission
            if (ContextCompat.checkSelfPermission(NotificationPermission.this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(NotificationPermission.this,
                        new String[]{Manifest.permission.SEND_SMS},
                        REQUEST_SMS_PERMISSION);
            }
            else {
                //Send an SMS message if permission is granted
                sendSmsAlert();
            }
        });

        //listener for no thanks button
        noThanksButton.setOnClickListener(v -> {
            // Do nothing when "No Thanks" button is clicked
        });

        //listener for back arrow button
        backArrow.setOnClickListener(v -> {
            onBackPressed(); // Go back to the previous screen
        });
    }

    // This method displays the results when permission is or isn't granted
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case REQUEST_SMS_PERMISSION:
                //IF permission is granted sendSmsAlert method is called
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    sendSmsAlert();
                }
                // if not display a message that it was not granted
                else {
                    Toast.makeText(NotificationPermission.this, "SMS permission was not granted!", Toast.LENGTH_SHORT).show();
                }
        }
    }

    //This method sends an SMS message to "my phone number"
    private void sendSmsAlert() {
        String phoneNumber = "7144961953";
        String message = "You have granted permission to receive SMS messages from Inventory App";

        //Send SMS messages when the user grants permission
        if (ContextCompat.checkSelfPermission(NotificationPermission.this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(NotificationPermission.this, "The SMS was sent successfully!", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(NotificationPermission.this, "The SMS could not be sent, please try again!", Toast.LENGTH_SHORT).show();
        }
    }
}
